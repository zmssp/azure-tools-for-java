/**
 * Created by ltian on 6/22/2017.
 */


function renderJobGraph(job) {
    g = new dagreD3.graphlib.Graph()
        .setGraph({})
        .setDefaultEdgeLabel(function() { return {}; });

    var id = job['JobID'];
    var stageIds = job['StageIDs'];
    var stageInfos = job['StageInfos'];
    stageInfos.sort(function(left, right) {
        return left['StageID'] > right['StageID'];
    });
    // for virtual job node
    g.setNode(-1, {label :'Job ' + id,   class : 'type-TOP'});

    stageInfos.forEach(function(stage) {
        var id = stage['StageID'];
        g.setNode(id, {'label' : 'stage'});
        var parentNodes = stage['ParentIDs'];
        if (parentNodes.length === 0) {
            g.setEdge(-1, id);
        } else {
            parentNodes.forEach(function(parentId) {
                g.setEdge(parentId, id);
            });
        }
    });

    // Create the renderer
    var render = new dagreD3.render();

// Set up an SVG group so that we can translate the final graph.
    var svg = d3.select("#jobGraphSvg");

    // remove all graph first
    d3.selectAll("#jobGraphSvg g").remove();

    var inner = svg.append("g");

// Run the renderer. This is what draws the final graph.
    render(d3.select("#jobGraphSvg g"), g);

    var g_width = g.graph().width ;
    var g_height = g.graph().height ;
    var viewBoxValue = "0 0 " + g_width + " " + g_height;
    svg.attr("viewBox", viewBoxValue);
    svg.attr("preserveAspectRatio", "xMidYMid meet");

    render(d3.select("#jobGraphSvg g"), g);
// Center the graph
    var width = $("#jobGraphSvg").width();
    var height = $("#jobGraphSvg").height();

    var zoom = d3.behavior.zoom().on("zoom", function() {
        inner.attr("transform", "translate(" + d3.event.translate + ")" +
            "scale(" + d3.event.scale + ")");
    });
    svg.call(zoom);
}


$(function () {
     var s2 = '{  "Job ID  ": 0,  "Stage Infos  ": [{  "Stage ID  ": 0,   "Stage Attempt ID  ": 0,  "Stage Name  ":   "flatMap at SparkCore_WasbIOTest.scala:27  ",  "Parent IDs  ": []},{  "Stage ID  ": 1,  "Stage Attempt ID  ": 0,  "Stage Name  ":   "flatMap at SparkCore_WasbIOTest.scala:19  ",   "Parent IDs  ": []}, {  "Stage ID  ": 2,  "Stage Attempt ID  ": 0,  "Stage Name  ":   "sortByKey at SparkCore_WasbIOTest.scala:38  ",  "Parent IDs  ": [0,1]}],  "Stage IDs  ": [0,1,2]}';
     var s3 = s2.replace(/\s+/g, '');
     var currentJobs = JSON.parse(s3);
    renderJobGraph(currentJobs);
})

