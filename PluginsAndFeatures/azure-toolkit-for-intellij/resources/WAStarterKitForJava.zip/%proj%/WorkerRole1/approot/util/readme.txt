Following content from Azure SDK 2.8.0 "bin\plugins\Caching" directory should be under this directory:

Microsoft.WindowsAzure.Storage.dll
Microsoft.Data.Services.Client.dll
Microsoft.Data.Edm.dll
Microsoft.Data.OData.dll
Newtonsoft.Json.dll
System.Spatial.dll
Microsoft.WindowsAzure.Configuration.dll
