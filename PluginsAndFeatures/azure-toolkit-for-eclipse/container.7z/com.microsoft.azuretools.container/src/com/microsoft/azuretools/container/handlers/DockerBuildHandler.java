package com.microsoft.azuretools.container.handlers;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

import com.microsoft.azuretools.core.utils.AzureAbstractHandler;

public class DockerBuildHandler extends AzureAbstractHandler {

	@Override
	public Object onExecute(ExecutionEvent event) throws ExecutionException {
		System.out.println("DockerizeHandler");
		return null;
	}

}
