package com.microsoft.azuretools.container.handlers;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jst.j2ee.datamodel.properties.IJ2EEComponentExportDataModelProperties;
import org.eclipse.jst.j2ee.internal.web.archive.operations.WebComponentExportDataModelProvider;
import org.eclipse.wst.common.frameworks.datamodel.DataModelFactory;
import org.eclipse.wst.common.frameworks.datamodel.IDataModel;

import com.microsoft.azuretools.core.utils.AzureAbstractHandler;

public class DockerRunHandler extends AzureAbstractHandler {

	@Override
	public Object onExecute(ExecutionEvent event) throws ExecutionException {
		System.out.println("DockerizeHandler");
		try {
			IProject project = null; // todo
			String projectName = project.getName();
	    String destinationPath = project.getLocation() + "/" + projectName + ".war";
			export(projectName, destinationPath);
			//docker run 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void export(String projectName, String destinationPath) throws Exception {

    System.out.println("Building project '" + projectName + "'...");
    IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectName);
    project.build(IncrementalProjectBuilder.FULL_BUILD, null);

    System.out.println("Exporting to WAR...");
    IDataModel dataModel = DataModelFactory.createDataModel(new WebComponentExportDataModelProvider());
    dataModel.setProperty(IJ2EEComponentExportDataModelProperties.PROJECT_NAME, projectName);
    dataModel.setProperty(IJ2EEComponentExportDataModelProperties.ARCHIVE_DESTINATION, destinationPath);

    dataModel.getDefaultOperation().execute(null, null);
    System.out.println("Done.");
}

}
