package com.microsoft.azuretools.container;

//import com.spotify.docker.client;
public class Utils {
//	final DockerClient docker = DefaultDockerClient.fromEnv().build();
}
