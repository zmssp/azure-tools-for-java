#!/usr/bin/env bash

livy_pid_dir="/var/run/livy"
livy_log_dir="/var/log/livy"

#create those directories if they don't already exist
mkdir -p "$livy_pid_dir"
mkdir -p "$livy_log_dir"

pid="$livy_pid_dir/livy-1.pid"

livy_home="/opt/livy/livy-server-0.2.0-SNAPSHOT"
command="$livy_home/bin/livy-server"

echo "starting $command, logging to $log"

# Load system-wide environment variables.
set -a
source /etc/environment
set +a

export YARN_CLASSPATH=`yarn classpath`
export CLASSPATH="$YARN_CLASSPATH:/usr/lib/hdinsight-logging/*"

nohup nice -n 0 "$livy_home"/bin/livy-server > /dev/null &
newpid="$!"

echo "$newpid" > "$pid"
sleep 2
# Check if the process has died; in that case we'll tail the log so the user can see
if [[ ! $(ps -p "$newpid" -o comm=) =~ "java" ]]; then
  echo "failed to launch $command"
fi


