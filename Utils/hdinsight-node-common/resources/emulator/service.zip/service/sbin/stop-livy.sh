#!/usr/bin/env bash

livy_pid_dir="/var/run/livy"
pid="$livy_pid_dir/livy-1.pid"

if [ -f $pid ]; then
  TARGET_ID="$(cat "$pid")"
  if [[ $(ps -p "$TARGET_ID" -o comm=) =~ "java" ]]; then
    echo "stopping livy"
    kill "$TARGET_ID" && rm -f "$pid"
  else
    echo "process not java"
  fi
else
  echo "no pid file found"
fi

