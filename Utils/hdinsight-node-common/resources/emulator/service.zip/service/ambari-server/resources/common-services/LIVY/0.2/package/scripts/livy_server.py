#!/usr/bin/env python
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

"""
import os
import socket
import subprocess
import sys
import tempfile
import urllib2

from resource_management import *
from resource_management.core.resources.system import File, Execute
from resource_management.libraries.functions.check_process_status import check_process_status

class LivyInstall(Script):

  def install(self, env):
    self.configure(env)
	
  def configure(self, env):
    import params
    env.set_params(params)
	
    #create log4j.properties in $livy_home/conf dir
    File(os.path.join(params.livy_conf_dir, 'log4j.properties'),
         owner=params.spark_user,
         group=params.user_group,
         content=params.livy_log4j_properties
    )

    PropertiesFile(format("{livy_conf_dir}/livy-defaults.conf"),
        properties = params.config['configurations']['livy-defaults'],
        key_value_delimiter = " = ",
        owner=params.spark_user,
        group=params.user_group
    )
  
  def start(self, env, rolling_restart=False):
    import params
    env.set_params(params)

    self.configure(env)

    Directory([params.livy_pid_dir],
            owner=params.spark_user,
            group=params.user_group,
            recursive=True
    )

    livy_no_op_test = format(
		'ls {livy_pid_file} >/dev/null 2>&1 && ps -p `cat {livy_pid_file}` >/dev/null 2>&1')
    Execute(format('{livy_start}'),
            user=params.spark_user,
			not_if=livy_no_op_test)
			  
  def stop(self, env, rolling_restart=False):
    import params
    env.set_params(params)
    
    Execute(format('{livy_stop}'),
            user=params.spark_user)
    File(format('{livy_pid_file}'),
      action="delete"
    )

  def status(self, env):
    import params
    env.set_params(params)

    check_process_status(params.livy_pid_file)
	
if __name__ == "__main__":
  LivyInstall().execute()
